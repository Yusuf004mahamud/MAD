# Tenant Management System — Simplified BBT3202 Practicals

This project implements the two supplied practical PDFs as one simple Kotlin/XML Android app.

## What is included
- Add Tenant screen using ConstraintLayout
- View Binding
- Data Binding
- Tenant data class and `summary()`
- Login screen
- Register screen
- Explicit Intents between activities
- `putExtra("EMAIL", email)` and `getStringExtra("EMAIL")`
- Login as launcher activity
- Website opened with `ACTION_VIEW`
- Tenant phone opened with `ACTION_DIAL`
- Basic empty-field validation

## Package name
`com.example.tenantmanagementsystem`

## How to open
1. Extract the ZIP.
2. Open the extracted `TenantManagementSystem` folder in Android Studio.
3. Let Gradle sync.
4. Create/run a Pixel emulator or connect an Android phone.
5. Run the app.

## Test sequence
1. App opens on Login.
2. Tap Register.
3. Enter name, email and password.
4. Tap Register. The email is sent back to Login.
5. Enter a password and tap Login.
6. Enter tenant name, phone and rent.
7. Tap Save. The Tenant object is displayed through Data Binding.
8. Tap Call Tenant. The phone dialer opens with the number filled in.
9. Back on Login, tap the website help link to open the Strathmore website.

No database/authentication is included because the practical explicitly says that, for now, any non-empty email and password can log in.
